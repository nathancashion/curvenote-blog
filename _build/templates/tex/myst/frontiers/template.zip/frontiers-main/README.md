# Frontiers

A template for Frontiers In Journals.

[](./thumbnail.png)

- Author: [Frontiers In](https://www.frontiersin.org/)
- [Source](https://www.frontiersin.org/about/author-guidelines)
